# UniFinder Clean V2

This version is rebuilt from scratch to avoid the native function-call parsing
errors encountered earlier.

## Architecture

User → Groq Router → DIRECT / OUT_OF_SCOPE / SEARCH

If SEARCH:
Groq decision → Python calls Tavily → Tavily results → Groq final answer

The LLM still decides whether the search tool should be used. There is no
hard-coded rule like `if "latest" in question: search()`.

## Setup

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your real keys.

Then:

```powershell
python test_connections.py
python main.py
python -m streamlit run app.py
```

## Test sequence

1. `What is photosynthesis?`
   - Expected decision: out_of_scope

2. `What is a bachelor's degree?`
   - Expected decision: direct

3. `Which universities in Germany currently offer English-taught master's programs in artificial intelligence?`
   - Expected decision: search
   - Terminal should print `TAVILY SEARCH TOOL CALLED`

4. Follow up with:
   `What about the tuition for the second one?`
   - Chat history should let the router resolve "the second one".
