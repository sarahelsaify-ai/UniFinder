import streamlit as st
from agent import run_agent

st.set_page_config(page_title="UniFinder", page_icon="🎓", layout="centered")

st.title("🎓 UniFinder")
st.caption("University Finder Agent • Groq + Tavily • Multi-turn chat")

if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    st.subheader("How it works")
    st.write(
        "The LLM first decides whether your question should be answered "
        "directly or requires a Tavily web search."
    )
    st.markdown("""
**Try:**
- What is a bachelor's degree?
- Which universities in Germany currently offer English-taught AI master's programs?
- What about the tuition for the second one?
- Does it require IELTS?
""")
    if st.button("🗑️ Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message["role"] == "assistant":
            meta = message.get("meta", {})
            if meta.get("used_search"):
                with st.expander("Search details"):
                    st.write(f"**Decision:** {meta.get('action')}")
                    st.write(f"**Search query:** {meta.get('search_query')}")
            sources = message.get("sources", [])
            if sources:
                with st.expander("Sources used"):
                    for source in sources:
                        sid = source.get("source_id", "Source")
                        title = source.get("title", "Source")
                        url = source.get("url", "")
                        if url:
                            st.markdown(f"**[{sid}]** [{title}]({url})")

prompt = st.chat_input("Ask about universities, admissions, programs, tuition, scholarships...")

if prompt:
    prior_history = [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages
        if m["role"] in {"user", "assistant"}
    ]

    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                result = run_agent(prompt, prior_history)
                answer = result["answer"]
                sources = result.get("sources", [])
                st.markdown(answer)

                if result.get("used_search"):
                    with st.expander("Search details"):
                        st.write(f"**Decision:** {result.get('action')}")
                        st.write(f"**Search query:** {result.get('search_query')}")

                if sources:
                    with st.expander("Sources used"):
                        for source in sources:
                            sid = source.get("source_id", "Source")
                            title = source.get("title", "Source")
                            url = source.get("url", "")
                            if url:
                                st.markdown(f"**[{sid}]** [{title}]({url})")

            except Exception as error:
                answer = f"Something went wrong: {error}"
                sources = []
                result = {"action": "error", "used_search": False, "search_query": ""}
                st.error(answer)

    st.session_state.messages.append({
        "role": "assistant",
        "content": answer,
        "sources": sources,
        "meta": {
            "action": result.get("action"),
            "used_search": result.get("used_search", False),
            "search_query": result.get("search_query", ""),
        },
    })
