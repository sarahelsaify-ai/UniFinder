import os
from typing import Any
from dotenv import load_dotenv
from tavily import TavilyClient

load_dotenv()
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

if not TAVILY_API_KEY:
    raise ValueError("TAVILY_API_KEY is missing. Create a .env file and add your Tavily key.")

tavily_client = TavilyClient(api_key=TAVILY_API_KEY)

def search_universities(query: str) -> dict[str, Any]:
    query = (query or "").strip()
    if not query:
        return {"query": "", "results": [], "error": "Empty search query."}

    print("\n" + "=" * 58)
    print("TAVILY SEARCH TOOL CALLED")
    print(f"Query: {query}")
    print("=" * 58 + "\n")

    response = tavily_client.search(
        query=query,
        search_depth="basic",
        max_results=5,
        include_answer=False,
    )

    results = []
    for index, result in enumerate(response.get("results", []), start=1):
        results.append({
            "source_id": f"S{index}",
            "title": result.get("title") or "Untitled result",
            "url": result.get("url") or "",
            "content": result.get("content") or "",
        })

    return {"query": query, "results": results}
