import os
from dotenv import load_dotenv
from groq import Groq
from tavily import TavilyClient

load_dotenv()

groq_key = os.getenv("GROQ_API_KEY")
tavily_key = os.getenv("TAVILY_API_KEY")

print("Checking environment variables...")

if not groq_key:
    raise ValueError("GROQ_API_KEY is missing from .env")
if not tavily_key:
    raise ValueError("TAVILY_API_KEY is missing from .env")

print("GROQ_API_KEY loaded ✅")
print("TAVILY_API_KEY loaded ✅")

print("\nTesting Groq...")
groq_client = Groq(api_key=groq_key)

groq_response = groq_client.chat.completions.create(
    model="openai/gpt-oss-120b",
    messages=[{"role": "user", "content": "Reply with exactly: Groq connection works"}],
)
print(groq_response.choices[0].message.content)

print("\nTesting Tavily...")
tavily_client = TavilyClient(api_key=tavily_key)

tavily_response = tavily_client.search(
    query="official university admissions",
    search_depth="basic",
    max_results=1,
    include_answer=False,
)

print(f"Tavily returned {len(tavily_response.get('results', []))} result(s).")
print("\nConnections are ready ✅")
