from agent import run_agent

print("=" * 65)
print("UNIFINDER - UNIVERSITY FINDER ASSISTANT")
print("=" * 65)
print("Ask about universities, admissions, programs, tuition, or scholarships.")
print("This CLI remembers the conversation for follow-up questions.")
print("Type 'exit' to close the program.\n")

history = []

while True:
    question = input("You: ").strip()

    if question.lower() in {"exit", "quit"}:
        print("Goodbye!")
        break

    if not question:
        continue

    try:
        result = run_agent(user_query=question, chat_history=history)
        answer = result["answer"]

        print("\nUniFinder:")
        print(answer)
        print(f"\nDecision: {result['action']}")

        if result.get("used_search"):
            print(f"Search query: {result['search_query']}")
            if result.get("sources"):
                print("\nSources:")
                for source in result["sources"]:
                    print(f"[{source['source_id']}] {source['title']} - {source['url']}")

        print("\n" + "-" * 65 + "\n")

        history.append({"role": "user", "content": question})
        history.append({"role": "assistant", "content": answer})

    except Exception as error:
        print("\nERROR:")
        print(error)
        print()
